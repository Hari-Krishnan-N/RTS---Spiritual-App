package com.example.rhythmbhara_tara_sadhana

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
